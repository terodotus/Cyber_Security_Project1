from django.shortcuts import render
from django.http import HttpResponse


def homePageView1(request):
	url = 'http://www.thefamouspeople.com/singers.php'
	http = urllib3.PoolManager()
	response = http.request('GET', url).info()
	return HttpResponse(response.content)


def homePageView(request):
	return HttpResponse('hello')