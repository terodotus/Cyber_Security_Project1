from django.apps import AppConfig


class MessagingConfig(AppConfig):
    name = 'messaging'
