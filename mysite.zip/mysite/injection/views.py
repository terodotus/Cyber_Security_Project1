from django.shortcuts import render
from .models import Message

# Create your views here.
def homePageView(request):
	return render(request, 'injection/index.html', {})
	
	
def message_search(request):
    if 'senderName' in request.GET:
        query = "SELECT * from Message WHERE message.senderName = %s" % senderName
        model_items = Message.objects.raw(query)
    else:
        model_items = Message.objects.all()
    return render(request, 'injection/index.html', {'model_items': model_items})