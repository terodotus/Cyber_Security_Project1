from django.contrib import admin, auth
from django.urls import path, include
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    path('admin/', admin.site.urls),
	path('music/', include('music.urls')),
	path('injection/', include('injection.urls')),
	path('messaging/', include('messaging.urls')),
	path('login/', LoginView.as_view(template_name='injection/login.html')),
	path('logout/', LogoutView.as_view(next_page='/')),
	
]
