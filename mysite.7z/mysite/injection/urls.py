from django.urls import path

from .views import homePageView, message_search

urlpatterns = [
    path('', homePageView, name='home'),
	path('message_search/', message_search, name='viestit'),
	
]
