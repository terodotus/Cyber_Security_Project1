from django.apps import AppConfig


class InjectionConfig(AppConfig):
    name = 'injection'
